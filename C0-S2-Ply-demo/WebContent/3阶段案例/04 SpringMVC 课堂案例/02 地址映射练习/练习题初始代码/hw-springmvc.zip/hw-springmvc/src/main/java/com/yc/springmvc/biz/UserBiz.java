package com.yc.springmvc.biz;

public class UserBiz {

}
