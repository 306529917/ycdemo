package com.yc.springmvc.biz;

public class ProductBiz {

}
