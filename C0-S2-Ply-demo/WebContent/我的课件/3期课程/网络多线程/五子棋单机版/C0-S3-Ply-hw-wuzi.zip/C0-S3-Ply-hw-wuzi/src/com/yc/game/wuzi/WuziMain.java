package com.yc.game.wuzi;

import com.yc.game.wuzi.core.WuziGameImpl;
import com.yc.game.wuzi.swing.WuziWin;

/**
 * 五子棋主程序
 * @author 廖彦
 */

public class WuziMain {
	public static void main(String[] args) {
		// 传入游戏实现类对象
		new WuziWin(new WuziGameImpl()).start();
	}

}
