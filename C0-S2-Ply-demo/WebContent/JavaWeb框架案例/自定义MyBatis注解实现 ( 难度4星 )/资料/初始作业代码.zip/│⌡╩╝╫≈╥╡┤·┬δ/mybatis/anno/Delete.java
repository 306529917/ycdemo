package com.yc.demo.aop.mybatis.anno;

public @interface Delete {
	public String value();
}
