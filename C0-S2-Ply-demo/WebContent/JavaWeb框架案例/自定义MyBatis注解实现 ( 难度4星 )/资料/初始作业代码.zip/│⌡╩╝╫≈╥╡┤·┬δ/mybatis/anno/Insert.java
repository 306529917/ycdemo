package com.yc.demo.aop.mybatis.anno;

public @interface Insert {
	public String value();
}
