package com.yc.demo.aop.mybatis.anno;

public @interface Select {
	
	public String value();

}
