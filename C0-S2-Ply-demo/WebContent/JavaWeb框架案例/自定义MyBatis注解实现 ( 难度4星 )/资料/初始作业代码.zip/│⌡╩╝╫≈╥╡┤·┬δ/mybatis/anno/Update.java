package com.yc.demo.aop.mybatis.anno;

public @interface Update {
	
	public String value();

}
